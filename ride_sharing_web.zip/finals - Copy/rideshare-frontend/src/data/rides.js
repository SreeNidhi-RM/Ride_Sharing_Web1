export const rides = [
    {
        id: 1,
        type: "Four Wheeler",
        timings: "6:00 AM - 11:00 PM",
        cost: 50,
        sharer: { name: "John Doe", vehicle: "Toyota Innova", experience: "5 years" }
    },
    {
        id: 2,
        type: "Two Wheeler",
        timings: "5:00 AM - 11:00 PM",
        cost: 20,
        sharer: { name: "Alice Smith", vehicle: "Bajaj Pulsar", experience: "3 years" }
    }
];
