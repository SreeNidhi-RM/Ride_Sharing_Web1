import React, { useState } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Features from "./components/Features";
import Transport from "./components/Transport";
import Contact from "./components/Contact";
import LoginModal from "./components/LoginModal";
import RegisterModal from "./components/RegisterModal";
import "./styles.css";

const App = () => {
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  return (
    <div>
      {/* Header with Login/Register buttons */}
      <Header
        onLoginClick={() => setShowLogin(true)}
        onRegisterClick={() => setShowRegister(true)}
      />

      {/* Hero section with Register button */}
      <Hero onRegisterClick={() => setShowRegister(true)} />

      {/* Other sections */}
      <About />
      <Features />
      <Transport />
      <Contact />

      {/* Modals */}
      <LoginModal show={showLogin} onClose={() => setShowLogin(false)} />
      <RegisterModal show={showRegister} onClose={() => setShowRegister(false)} />
    </div>
  );
};

export default App;
