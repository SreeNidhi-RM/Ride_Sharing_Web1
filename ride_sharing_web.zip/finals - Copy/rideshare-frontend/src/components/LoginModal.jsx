import React, { useState } from "react";
import "../styles.css"; // Make sure modal styles are included

const LoginModal = ({ show, onClose }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  if (!show) return null; // hide modal if show is false

  const handleSubmit = (e) => {
    e.preventDefault();

    // Mock login check
    if (email === "user@example.com" && password === "123456") {
      alert("Login successful!");
      setEmail("");
      setPassword("");
      onClose(); // close modal
    } else {
      alert("Invalid credentials!");
    }
  };

  return (
    <div
      className="modal"
      onClick={(e) => e.target === e.currentTarget && onClose()}
      style={{
        backdropFilter: "blur(5px)",
        backgroundColor: "rgba(0,0,0,0.4)",
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 999,
      }}
    >
      <div
        className="modal-content"
        style={{
          background: "rgba(255,255,255,0.9)",
          backdropFilter: "blur(10px)",
          padding: "30px",
          borderRadius: "20px",
          width: "90%",
          maxWidth: "400px",
          boxShadow: "0 15px 30px rgba(0,0,0,0.2)",
          position: "relative",
          animation: "slideDown 0.4s ease",
        }}
      >
        <span
          className="close"
          onClick={onClose}
          style={{
            position: "absolute",
            top: "15px",
            right: "20px",
            fontSize: "28px",
            fontWeight: "bold",
            color: "#007BFF",
            cursor: "pointer",
            transition: "color 0.2s",
          }}
          onMouseEnter={(e) => (e.target.style.color = "#0056b3")}
          onMouseLeave={(e) => (e.target.style.color = "#007BFF")}
        >
          &times;
        </span>

        <h2 style={{ textAlign: "center", marginBottom: "20px", color: "#007BFF" }}>Login</h2>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
              transition: "0.3s",
            }}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
            }}
          />

          <button
            type="submit"
            className="submit-btn"
            style={{
              background: "#007BFF",
              color: "#fff",
              padding: "12px 20px",
              border: "none",
              borderRadius: "50px",
              cursor: "pointer",
              fontSize: "16px",
              fontWeight: "600",
              transition: "0.3s",
            }}
            onMouseEnter={(e) => (e.target.style.background = "#0056b3")}
            onMouseLeave={(e) => (e.target.style.background = "#007BFF")}
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginModal;
