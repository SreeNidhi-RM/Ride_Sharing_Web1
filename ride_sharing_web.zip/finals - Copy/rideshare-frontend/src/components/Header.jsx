// src/components/Header.jsx
import React from "react";
import logo from "../assets/ridelogo.jpg"; // import the image
const Header = ({ onLoginClick, onRegisterClick }) => (
  <header>
    <div className="container">
      <div className="logo">
       <img src={logo} alt="RideShare Logo" />
        <h1>RideShare</h1>
      </div>
      <nav>
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#transport">Transport</a></li>
          <li><a href="#contact">Contact</a></li>
          <li><button type="button" onClick={onLoginClick}>Login</button></li>
          <li><button type="button" onClick={onRegisterClick}></button></li>
        </ul>
      </nav>
    </div>
  </header>
);

export default Header; // ✅ default export
