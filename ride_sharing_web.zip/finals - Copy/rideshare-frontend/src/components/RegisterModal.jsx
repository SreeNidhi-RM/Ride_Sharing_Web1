import React, { useState } from "react";
import "../styles.css";

const RegisterModal = ({ show, onClose }) => {
  const [formData, setFormData] = useState({
    fullname: "",
    email: "",
    phone: "",
    password: "",
    transport: "",
    departureDate: "",
    departurePlace: ""
  });

  if (!show) return null;

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { fullname, email, phone, password } = formData;

    if (!fullname || !email || !phone || !password) {
      alert("Please fill in required fields.");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      alert("Enter a valid email.");
      return;
    }

    if (!/^\d{10}$/.test(phone)) {
      alert("Enter a 10-digit phone number.");
      return;
    }

    if (password.length < 6) {
      alert("Password must be at least 6 characters.");
      return;
    }

    alert("Registration successful!");
    setFormData({
      fullname: "",
      email: "",
      phone: "",
      password: "",
      transport: "",
      departureDate: "",
      departurePlace: ""
    });
    onClose();
  };

  return (
    <div
      className="modal"
      onClick={(e) => e.target === e.currentTarget && onClose()}
      style={{
        backdropFilter: "blur(5px)",
        backgroundColor: "rgba(0,0,0,0.4)",
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 999,
      }}
    >
      <div
        className="modal-content"
        style={{
          background: "rgba(255,255,255,0.9)",
          backdropFilter: "blur(10px)",
          padding: "30px",
          borderRadius: "20px",
          width: "90%",
          maxWidth: "450px",
          boxShadow: "0 15px 30px rgba(0,0,0,0.2)",
          position: "relative",
          animation: "slideDown 0.4s ease",
        }}
      >
        <span
          className="close"
          onClick={onClose}
          style={{
            position: "absolute",
            top: "15px",
            right: "20px",
            fontSize: "28px",
            fontWeight: "bold",
            color: "#007BFF",
            cursor: "pointer",
            transition: "color 0.2s",
          }}
          onMouseEnter={e => e.target.style.color="#0056b3"}
          onMouseLeave={e => e.target.style.color="#007BFF"}
        >
          &times;
        </span>

        <h2 style={{ textAlign: "center", marginBottom: "20px", color: "#007BFF" }}>Register</h2>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
          <input
            id="fullname"
            type="text"
            placeholder="Full Name"
            value={formData.fullname}
            onChange={handleChange}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
              transition: "0.3s",
            }}
          />
          <input
            id="email"
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
            }}
          />
          <input
            id="phone"
            type="tel"
            placeholder="Phone"
            value={formData.phone}
            onChange={handleChange}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
            }}
          />
          <input
            id="password"
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
            }}
          />
          <select
            id="transport"
            value={formData.transport}
            onChange={handleChange}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              fontSize: "16px",
            }}
          >
            <option value="">Preferred Transport</option>
            <option value="car">Car</option>
            <option value="bike">Bike</option>
          </select>
          <input
            id="departureDate"
            type="date"
            value={formData.departureDate}
            onChange={handleChange}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
            }}
          />
          <input
            id="departurePlace"
            type="text"
            placeholder="Departure Place"
            value={formData.departurePlace}
            onChange={handleChange}
            style={{
              padding: "12px 15px",
              borderRadius: "10px",
              border: "1px solid #ccc",
              outline: "none",
              fontSize: "16px",
            }}
          />

          <button
            type="submit"
            className="submit-btn"
            style={{
              background: "#007BFF",
              color: "#fff",
              padding: "12px 20px",
              border: "none",
              borderRadius: "50px",
              cursor: "pointer",
              fontSize: "16px",
              fontWeight: "600",
              transition: "0.3s",
            }}
            onMouseEnter={e => e.target.style.background="#0056b3"}
            onMouseLeave={e => e.target.style.background="#007BFF"}
          >
            Register
          </button>
        </form>
      </div>
    </div>
  );
};

export default RegisterModal;
