import React from "react";

const Hero = ({ onRegisterClick }) => (
  <section
    id="hero"
    className="hero"
    style={{
      backgroundImage: `url("/rideepic.png")`,
      backgroundPosition: "center",
      backgroundSize: "cover",
      backgroundRepeat: "no-repeat",
      color: "#fff",
      textAlign: "center",
      padding: "120px 20px",
      position: "relative",
    }}
  >
    {/* Overlay */}
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        background: "rgba(0,0,0,0.4)",
        zIndex: 1,
      }}
    />

    {/* Text Content */}
    <div style={{ position: "relative", zIndex: 2 }}>
      <h2>TRAVEL WITH RIDESHARE</h2>
      <p>Comfortable, cost-effective, and faster transportation at your fingertips.</p>
      <button className="cta-button" onClick={onRegisterClick}>
        REGISTER HERE
      </button>
    </div>
  </section>
);

export default Hero;
