import React from "react";

const About = () => (
  <section
    id="about"
    className="about"
    style={{
      // Very light blue gradient background
      background: "linear-gradient(135deg, #e0f7fa, #b2ebf2)", 
      color: "#000", // black text for readability on light background
      padding: "10px 20px",
      position: "relative",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      textAlign: "center",
      minHeight: "500px",
    }}
  >
    {/* Content */}
    <div style={{ maxWidth: "800px" }}>
      <h2>ABOUT US</h2>
      <p>
        RideShare is your reliable partner for convenient and cost-effective transportation solutions. Our platform connects drivers and passengers, providing flexible and comfortable ride-sharing options to suit your needs.

        At RideShare, we believe in leveraging technology to create a seamless and enjoyable travel experience. Our core values include:

        <strong>Flexibility:</strong> Choose your own timings and travel at your convenience.<br />
        <strong>Cost-effectiveness:</strong> Save money by sharing rides with others heading the same way.<br />
        <strong>Comfort:</strong> Enjoy comfortable rides with verified ride sharers.<br />

        Our mission is to reduce travel stress and promote a greener environment by encouraging ride sharing. Whether you need a ride for work, leisure, or any other purpose, RideShare is here to make your journey smooth and enjoyable.

        Join us today and be a part of a community that values convenience, affordability, and sustainability. Travel smart with RideShare!
      </p>
    </div>
  </section>
);

export default About;
