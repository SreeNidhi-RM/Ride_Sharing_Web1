import React from "react";
import { rides } from "../data/rides";

const Transport = () => (
  <section
    id="transport"
    className="transport"
    style={{
      background: "linear-gradient(135deg, #e0f7fa, #b2ebf2)", // light blue gradient
      padding: "5px 20px",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      minHeight: "500px",
    }}
  >
    <div
      className="container transport-grid"
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: "20px",
        justifyContent: "center",
        maxWidth: "1200px",
      }}
    >
      {rides.map((ride) => (
        <div
          className="transport-item"
          key={ride.id}
          style={{
            background: "#fff",
            padding: "25px",
            borderRadius: "15px",
            boxShadow: "0 10px 20px rgba(0,0,0,0.1)",
            width: "280px",
            textAlign: "center",
            transition: "transform 0.3s, box-shadow 0.3s",
          }}
        >
          <i
            className={`bi ${
              ride.type === "Four Wheeler"
                ? "bi-car-front-fill"
                : "bi-bicycle"
            }`}
            style={{ fontSize: "3rem", color: "#007BFF", marginBottom: "15px" }}
          ></i>
          <h3 style={{ color: "#007BFF" }}>{ride.type}</h3>
          <p>Timings: {ride.timings}</p>
          <p>Cost: ₹{ride.cost}</p>
          <p>
            Sharer: {ride.sharer.name} ({ride.sharer.vehicle})
          </p>
        </div>
      ))}
    </div>
  </section>
);

export default Transport;
