import React, { useState } from "react";

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = e => {
    e.preventDefault();
    alert("Message sent successfully!");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <section
      id="contact"
      className="contact"
      style={{
        background: "linear-gradient(135deg, #e0f7fa, #b2ebf2)", // light blue gradient
        color: "#000", // black text for readability
        padding: "10px 20px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "500px",
        textAlign: "center",
      }}
    >
      <div style={{ maxWidth: "500px", width: "100%" }}>
        <h2>CONTACT US</h2>
        <form
          className="contact-form"
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column", gap: "15px" }}
        >
          <input
            type="text"
            placeholder="Full Name"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            required
            style={{ padding: "12px", borderRadius: "8px", border: "1px solid #ccc", outline: "none" }}
          />
          <input
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={e => setForm({ ...form, email: e.target.value })}
            required
            style={{ padding: "12px", borderRadius: "8px", border: "1px solid #ccc", outline: "none" }}
          />
          <textarea
            placeholder="Message"
            value={form.message}
            onChange={e => setForm({ ...form, message: e.target.value })}
            required
            rows="5"
            style={{ padding: "12px", borderRadius: "8px", border: "1px solid #ccc", outline: "none" }}
          />
          <button
            type="submit"
            className="submit-btn"
            style={{
              backgroundColor: "#007BFF",
              color: "#fff",
              padding: "12px",
              border: "none",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              transition: "background 0.3s",
            }}
            onMouseEnter={e => (e.target.style.backgroundColor = "#0056b3")}
            onMouseLeave={e => (e.target.style.backgroundColor = "#007BFF")}
          >
            Send Message
          </button>
        </form>
      </div>
    </section>
  );
};

export default Contact;
