import React from "react";

const Features = () => (
  <section
    id="features"
    className="features"
    style={{
      background: "linear-gradient(135deg, #e0f7fa, #b2ebf2)", // light blue gradient
      padding: "10px 20px",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      minHeight: "500px",
    }}
  >
    <div
      className="container feature-grid"
      style={{
        display: "flex",
        gap: "20px",
        flexWrap: "wrap",
        justifyContent: "center",
        maxWidth: "1200px",
      }}
    >
      <div
        className="feature-item"
        style={{
          background: "#fff",
          padding: "25px",
          borderRadius: "15px",
          boxShadow: "0 10px 20px rgba(0,0,0,0.1)",
          width: "280px",
          textAlign: "center",
          transition: "transform 0.3s, box-shadow 0.3s",
        }}
      >
        <h3 style={{ color: "#007BFF" }}>Flexible Timings</h3>
        <p>Choose your own timings for travel.</p>
      </div>

      <div
        className="feature-item"
        style={{
          background: "#fff",
          padding: "25px",
          borderRadius: "15px",
          boxShadow: "0 10px 20px rgba(0,0,0,0.1)",
          width: "280px",
          textAlign: "center",
          transition: "transform 0.3s, box-shadow 0.3s",
        }}
      >
        <h3 style={{ color: "#007BFF" }}>Cost-effective</h3>
        <p>Share rides and reduce cost.</p>
      </div>

      <div
        className="feature-item"
        style={{
          background: "#fff",
          padding: "25px",
          borderRadius: "15px",
          boxShadow: "0 10px 20px rgba(0,0,0,0.1)",
          width: "280px",
          textAlign: "center",
          transition: "transform 0.3s, box-shadow 0.3s",
        }}
      >
        <h3 style={{ color: "#007BFF" }}>Comfortable Rides</h3>
        <p>Verified and safe rides for everyone.</p>
      </div>
    </div>
  </section>
);

export default Features;
