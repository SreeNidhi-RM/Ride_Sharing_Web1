import React from "react";

const Footer = () => (
  <footer>
    <div className="container">
      <p>&copy; 2024 RideShare. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;
